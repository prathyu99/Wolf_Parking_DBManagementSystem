/**
 * 
 */
/**
 * 
 */
module DBMSProject {
	requires java.sql;
	requires mysql.connector.j;
}